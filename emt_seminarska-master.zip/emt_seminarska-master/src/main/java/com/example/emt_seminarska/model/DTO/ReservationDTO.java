package com.example.emt_seminarska.model.DTO;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ReservationDTO {
    private String date;
    private String time;
    private int persons;
    private String name;
    private String clientMessage;

    public ReservationDTO(String date, String time, int persons, String name, String clientMessage) {
        this.date = date;
        this.time = time;
        this.persons = persons;
        this.name = name;
        this.clientMessage = clientMessage;
    }
}
