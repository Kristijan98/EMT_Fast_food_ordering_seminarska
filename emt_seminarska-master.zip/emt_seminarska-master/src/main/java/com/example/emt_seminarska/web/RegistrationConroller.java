//package com.example.emt_seminarska.web;
//
//import com.example.emt_seminarska.model.DTO.UserDTO;
//import com.example.emt_seminarska.model.User;
//import com.example.emt_seminarska.service.interfacesImpl.UserInterfaceImpl;
//import org.springframework.ui.Model;
//import org.springframework.validation.Errors;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.ModelAttribute;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.context.request.WebRequest;
//import com.example.emt_seminarska.service.interfaces.UserInterface;
//import org.springframework.web.servlet.ModelAndView;
//
//import javax.servlet.http.HttpServletRequest;
//import javax.validation.Valid;
//
//public class RegistrationConroller {
//
//    public ModelAndView registerUserAccount(
//            @ModelAttribute("user") @Valid UserDTO userDto,
//            HttpServletRequest request, Errors errors) {
//
//        try {
//
//            User registered = UserInterface.registerNewUserAccount(userDto);
//        } catch (UserAlreadyExistException uaeEx) {
//            mav.addObject("message", "An account for that username/email already exists.");
//            return mav;
//        }
//
//        return new ModelAndView("successRegister", "user", userDto);
//    }
//}
