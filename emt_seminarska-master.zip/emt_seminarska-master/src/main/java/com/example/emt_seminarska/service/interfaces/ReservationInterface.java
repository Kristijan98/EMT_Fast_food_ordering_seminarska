package com.example.emt_seminarska.service.interfaces;

import com.example.emt_seminarska.model.DTO.ReservationDTO;
import com.example.emt_seminarska.model.Reservation;

import java.util.List;

public interface ReservationInterface {
//   List<Reservation> fetchReservations();
  void saveReservation(ReservationDTO reservationDTO);
   void deleteReservation(String id);
}
