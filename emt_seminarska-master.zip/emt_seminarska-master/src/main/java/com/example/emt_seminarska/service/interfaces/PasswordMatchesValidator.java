//package com.example.emt_seminarska.service.interfaces;
//
//import com.example.emt_seminarska.model.DTO.UserDTO;
//
//import javax.validation.ConstraintValidator;
//import javax.validation.ConstraintValidatorContext;
//
//public class PasswordMatchesValidator implements ConstraintValidator<PasswordMatches, Object> {
//   public void initialize(PasswordMatches constraint) {
//   }
//
//   @Override
//   public boolean isValid(Object obj, ConstraintValidatorContext context){
//      UserDTO user = (UserDTO) obj;
//      return user.getPassword().equals(user.getMatchingPassword());
//   }
//}
