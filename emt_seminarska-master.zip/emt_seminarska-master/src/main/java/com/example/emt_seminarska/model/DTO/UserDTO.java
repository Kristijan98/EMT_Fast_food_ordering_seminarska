package com.example.emt_seminarska.model.DTO;

//import com.example.emt_seminarska.service.interfaces.PasswordMatches;
//import com.example.emt_seminarska.service.interfaces.ValiddEmail;
import com.sun.istack.NotNull;
import lombok.*;

import javax.validation.constraints.NotEmpty;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
//@PasswordMatches
public class UserDTO {

    @NotNull
    private String firstName;

    @NotNull
    private String lastName;

    @NotNull
    private String password;
    private String matchingPassword;

//    @ValiddEmail
    @NotNull
    @NotEmpty
    private String email;



}
