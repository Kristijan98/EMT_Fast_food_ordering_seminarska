package com.example.emt_seminarska.service.interfacesImpl;

import com.example.emt_seminarska.Repository.ProductRepository;
import com.example.emt_seminarska.Repository.ShoppingCartRepository;
import com.example.emt_seminarska.Repository.UserRepository;
import com.example.emt_seminarska.model.Product;
import com.example.emt_seminarska.model.ShoppingCart;
import com.example.emt_seminarska.model.User;
import com.example.emt_seminarska.service.interfaces.ShoppingInterface;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class ShoppingCartInterfaceImpl implements ShoppingInterface {

    private final ShoppingCartRepository shoppingCartRepository ;
    private final ProductRepository productRepository;
    private final UserRepository userRepository;

    public ShoppingCartInterfaceImpl(ShoppingCartRepository shoppingCartRepository, ProductRepository productRepository, UserRepository userRepository) {
        this.shoppingCartRepository = shoppingCartRepository;
        this.productRepository = productRepository;
        this.userRepository = userRepository;
    }

    @Override
    public void deleteProduct(String productId) {
        Product deleteProduct = productRepository.findById(productId).get();

        User u = userRepository.findAll().stream()
                .findFirst()
                .get();
        u.getOrder().remove(deleteProduct);
        userRepository.save(u);
    }

    @Override
    public Optional<ShoppingCart> findProductById(Long id) {
        return shoppingCartRepository.findById(id);
    }



}
