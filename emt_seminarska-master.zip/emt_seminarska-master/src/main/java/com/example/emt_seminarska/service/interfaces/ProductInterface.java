package com.example.emt_seminarska.service.interfaces;

import com.example.emt_seminarska.model.Category;
import com.example.emt_seminarska.model.DTO.CategoryDTO;
import com.example.emt_seminarska.model.DTO.ProductDTO;
import com.example.emt_seminarska.model.Product;
import org.springframework.stereotype.Service;

import java.util.List;

public interface ProductInterface {

    List<Product> fetchProducts();
    void deleteProduct(String productId);

    void updateProduct(Product product);

    void saveNewProduct(ProductDTO productDTO, CategoryDTO categoryDTO);

    Product findProductById(String id);

    void addToCartProduct(String id);

}
