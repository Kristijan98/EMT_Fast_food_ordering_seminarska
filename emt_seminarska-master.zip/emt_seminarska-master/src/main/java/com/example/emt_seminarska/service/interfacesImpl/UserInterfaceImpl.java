package com.example.emt_seminarska.service.interfacesImpl;

import com.example.emt_seminarska.Repository.UserRepository;
import com.example.emt_seminarska.model.DTO.UserDTO;
//import com.example.emt_seminarska.model.DTO.UserLogin;
//import com.example.emt_seminarska.model.DTO.UserPasswordDTO;
import com.example.emt_seminarska.model.Product;
import com.example.emt_seminarska.model.User;
import com.example.emt_seminarska.service.interfaces.UserInterface;

import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.Arrays;
import java.util.List;

@Service
public class UserInterfaceImpl implements UserInterface {

    private final UserRepository userRepository;

    public UserInterfaceImpl(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public User fetchCurrentUser(String userId) {

        return userRepository.findById(userId).orElse(new User());
    }

//    @Transactional
//    @Override
//    public User registerNewUserAccount(UserDTO userDto)
//            throws UserAlreadyExistException {
//
////        if (emailExists(userDto.getEmail())) {
////            throw new UserAlreadyExistException(
////                    "There is an account with that email address: "
////                            + userDto.getEmail());
////        }
//        User user = new User();
//        user.setFirstName(userDto.getFirstName());
//        user.setLastName(userDto.getLastName());
//        user.setPassword(userDto.getPassword());
//        user.setEmail(userDto.getEmail());
//        user.setRoles(Arrays.asList("ROLE_USER"));
//        return userRepository.save(user);
//    }


//    private boolean emailExist(String email) {
//        return userRepository.findByEmail(email) != null;
//    }


    @Override
    public User updateUser(User user) {
        User inDataBase = userRepository.findById(user.getId()).get();

        inDataBase.setFirstName(user.getFirstName());
        inDataBase.setLastName(user.getLastName());
        inDataBase.setEmail(user.getEmail());


        userRepository.save(inDataBase);
        return inDataBase;
    }

    @Override
    public User changePasswordUser(UserDTO userDTO) {
        User inDataBase = userRepository.findAll()
                .stream()
                .filter(user -> user.getEmail().equals(userDTO.getEmail()))
                .findFirst()
                .get();

        inDataBase.setPassword(userDTO.getPassword());

        userRepository.save(inDataBase);

        return inDataBase;
    }

    @Override
    public User loginUser(UserDTO userLogin) {

        return userRepository.findAll()
                .stream()
                .filter(user -> user.getEmail().equals(userLogin.getEmail()))
                .findFirst()
                .get();
    }

    @Override
    public User findById(String id) {
        return userRepository.findById(id).get();
    }

    @Override
    public List<Product> fetchUserProductCart() {
        
        return userRepository.findAll()
                .stream()
                .findFirst()
                .get()
                .getOrder();
    }

    @Override
    public void deleteProduct(String id) {
        User u = userRepository.findAll()
                .stream()
                .findFirst()
                .get();

        Product p = u.getOrder()
                .stream()
                .filter(product -> product.getId().equals(id))
                .findFirst()
                .get();
        u.getOrder().remove(p);

        userRepository.save(u);
    }


}