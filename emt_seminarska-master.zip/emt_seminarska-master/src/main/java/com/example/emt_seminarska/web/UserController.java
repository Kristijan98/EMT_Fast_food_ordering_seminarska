package com.example.emt_seminarska.web;

import com.example.emt_seminarska.model.DTO.UserDTO;
//import com.example.emt_seminarska.model.DTO.UserLogin;
//import com.example.emt_seminarska.model.DTO.UserPasswordDTO;
import com.example.emt_seminarska.model.Product;
import com.example.emt_seminarska.model.User;
import com.example.emt_seminarska.service.interfaces.UserInterface;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpSession;
@Controller
@RequestMapping("/user")
public class UserController {

    private final UserInterface userInterface;

    public UserController(UserInterface userInterface) {
        this.userInterface = userInterface;
    }



    @GetMapping("/get-cart-products")
    private String userCart(HttpSession session) {
        session.setAttribute("userCart", userInterface.fetchUserProductCart());
        session.setAttribute("totalPrice", userInterface.fetchUserProductCart()
                .stream()
                .mapToInt(Product::getPrice).sum());
        session.setAttribute("currency","DOLLAR" );
        session.setAttribute("STRIPE_P_KEY" ,"pk_test_TKKQFrZ2nBlaSL3wILTdTfsh00Z3VIYNVg");
        return "cart";
    }

    @GetMapping("/delete-product/{id}")
    private String deleteProduct(@PathVariable String id) {
        userInterface.deleteProduct(id);
        return "redirect:/user/get-cart-products";
    }

}
