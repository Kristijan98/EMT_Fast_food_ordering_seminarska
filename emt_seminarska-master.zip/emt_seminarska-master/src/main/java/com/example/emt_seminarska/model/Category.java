package com.example.emt_seminarska.model;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Entity(name = "categories")
public class Category {

    @Id
    private Long id;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Column
    private String name;
/*
    @OneToMany(mappedBy = "product")
    private List<Product> listType;

 */
    public void setId(Long id){
        this.id=id;
    }

    public Long getId() {
        return id;
    }
}
