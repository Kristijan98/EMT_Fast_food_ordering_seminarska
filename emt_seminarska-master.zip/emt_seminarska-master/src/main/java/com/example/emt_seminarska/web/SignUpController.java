//package com.example.emt_seminarska.web;
//
//import com.example.emt_seminarska.service.interfaces.UserInterface;
//import com.example.emt_seminarska.model.User;
//import org.springframework.stereotype.Controller;
//import org.springframework.ui.Model;
//import org.springframework.web.bind.annotation.*;
//
//@Controller
//@RequestMapping("/signup")
//public class SignUpController {
//
//    private final UserInterface userInterface;
//
//    public SignUpController(UserInterface userInterface) {
//        this.userInterface = userInterface;
//    }
//
//    @GetMapping
//    public String getSignUpPage() {
//        return "signup";
//    }
//
//    @PostMapping
//    public String signUpUser(User user) {
//        try {
//            this.userInterface.updateUser(user);
//            return "redirect:/login?info=SuccessfulRegistration!";
//        } catch (RuntimeException ex) {
//            return "redirect:/signup?error=" + ex.getLocalizedMessage();
//        }
//    }
//}
