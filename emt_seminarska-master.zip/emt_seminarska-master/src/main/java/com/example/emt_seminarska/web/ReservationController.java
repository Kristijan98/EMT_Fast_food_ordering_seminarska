package com.example.emt_seminarska.web;

import com.example.emt_seminarska.model.DTO.CategoryDTO;
import com.example.emt_seminarska.model.DTO.ProductDTO;
import com.example.emt_seminarska.model.DTO.ReservationDTO;
import com.example.emt_seminarska.service.interfaces.ReservationInterface;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/reservations")
public class ReservationController {
    private final ReservationInterface reservationInterface;

    public ReservationController(ReservationInterface reservationInterface) {
        this.reservationInterface = reservationInterface;
    }

    @PostMapping("/save-reservation/{id}")
    private String saveReservation(@PathVariable ReservationDTO id) {
        reservationInterface.saveReservation(id);
        return "redirect:/reservations";
    }


    @PostMapping("/delete-reservation/{id}")
    private String deleteReservation(@PathVariable String id) {
        reservationInterface.deleteReservation(id);
        return "redirect:/reservations";
    }
    /*
    @PostMapping("/delete-reservation")
    private String deleteReservation(@PathVariable String id) {
        reservationInterface.deleteReservation(id);
        return "redirect:/reservations";
    }

     */

}
