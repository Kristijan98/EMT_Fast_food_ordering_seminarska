package com.example.emt_seminarska.model;

import com.example.emt_seminarska.model.User;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@AllArgsConstructor
@NoArgsConstructor
@Entity(name = "shopping carts")
public class ShoppingCart {

    @Id
    private Long id;

    @ManyToOne
    private User user;

    public void setId(Long id) {
        this.id = id;
    }

    public void setUser(User user) {
        this.user = user;
    }
    public Long getId() {
        return id;
    }

    public User getUser() {
        return user;
    }
}
