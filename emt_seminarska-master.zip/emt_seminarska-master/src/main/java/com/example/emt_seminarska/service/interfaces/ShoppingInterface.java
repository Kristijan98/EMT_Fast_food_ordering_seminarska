package com.example.emt_seminarska.service.interfaces;

import com.example.emt_seminarska.model.ShoppingCart;

import java.util.Optional;

public interface ShoppingInterface {

    void deleteProduct(String productId);
    Optional<ShoppingCart> findProductById(Long id);


}
