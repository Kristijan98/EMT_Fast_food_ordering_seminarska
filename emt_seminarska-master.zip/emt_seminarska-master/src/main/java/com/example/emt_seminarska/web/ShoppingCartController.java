package com.example.emt_seminarska.web;


import com.example.emt_seminarska.service.interfaces.ShoppingInterface;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/shopping-cart")
public class ShoppingCartController {

    private final ShoppingInterface shoppingInterface;

    public ShoppingCartController(ShoppingInterface shoppingInterface) {
        this.shoppingInterface = shoppingInterface;
    }

    @PostMapping("/delete-product/{id}")
    private String deleteProduct(@PathVariable String id) {
        shoppingInterface.deleteProduct(id);
        return "redirect:/user/get-cart-products";

//        return "redirect:/products/menu";
    }
}
