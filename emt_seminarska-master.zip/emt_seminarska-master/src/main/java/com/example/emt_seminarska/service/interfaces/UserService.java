package com.example.emt_seminarska.service.interfaces;

import com.example.emt_seminarska.model.User;

public interface UserService  {
    User findById(String userId);
    User registerUser(User user);
}
