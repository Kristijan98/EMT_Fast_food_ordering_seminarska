package com.example.emt_seminarska.Repository;

import com.example.emt_seminarska.model.ShoppingCart;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ShoppingCartRepository extends JpaRepository<ShoppingCart, Long> {
//    Optional<ShoppingCart> findByUserUsernameAndStatus(String username, CartStatus status);
//    boolean existsByUserUsernameAndStatus(String username, CartStatus status);

//    List<ShoppingCart> findAllByUserUsername(String username);
    Optional<ShoppingCart> findById(Long id);

}
