package com.example.emt_seminarska.service.interfaces;


import com.example.emt_seminarska.model.DTO.UserDTO;
//import com.example.emt_seminarska.model.DTO.UserLogin;
//import com.example.emt_seminarska.model.DTO.UserPasswordDTO;
import com.example.emt_seminarska.model.Product;
import com.example.emt_seminarska.model.User;

import java.util.*;

public interface UserInterface  {
    User fetchCurrentUser(String userId);

//    User registerNewUserAccount(UserDTO userDto) throws UserAlreadyExistException;

    User updateUser(User user);

    User changePasswordUser(UserDTO userDTO);

    User loginUser(UserDTO userLogin);

    User findById(String id);

    List<Product> fetchUserProductCart();

    void deleteProduct(String id);
}