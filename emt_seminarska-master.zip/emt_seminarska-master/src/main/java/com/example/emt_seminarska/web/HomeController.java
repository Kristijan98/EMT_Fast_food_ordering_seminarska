package com.example.emt_seminarska.web;

import com.example.emt_seminarska.Repository.InMemoryDB;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/")
public class HomeController {
    private final InMemoryDB inMemoryDB;

    public HomeController(InMemoryDB inMemoryDB) {
        this.inMemoryDB = inMemoryDB;
    }

    private String homePage() {
        return "index";
    }

    @GetMapping("/contact-us")
    private String contactPage() {
        return "contact";
    }

    @GetMapping("/reservations")
    private String reservationPage() {
        return "reservation";
    }

    @RequestMapping("/populate-db")
    private String populateDB() {
        inMemoryDB.populateDB();
        return "redirect:/";
    }

    @RequestMapping("/delete-db")
    private String deleteDB() {
        inMemoryDB.deleteDB();
        return "redirect:/";
    }
}
